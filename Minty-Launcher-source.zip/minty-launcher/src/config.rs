use anyhow::{Context, Result};
use directories::ProjectDirs;
use serde::{Deserialize, Serialize};
use std::{fs, path::PathBuf};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AppConfig {
    pub game_dir: PathBuf,
    pub selected_version: String,
    pub offline_username: String,
    pub microsoft_client_id: String,
    pub java_path: String,
    pub max_memory_gb: u8,
    pub last_account_name: Option<String>,
    pub last_account_uuid: Option<String>,
    pub last_account_xuid: Option<String>,
}

impl Default for AppConfig {
    fn default() -> Self {
        let game_dir = dirs_home().join(".minecraft");
        Self {
            game_dir,
            selected_version: "latest-release".to_owned(),
            offline_username: "Player".to_owned(),
            microsoft_client_id: String::new(),
            java_path: String::new(),
            max_memory_gb: 4,
            last_account_name: None,
            last_account_uuid: None,
            last_account_xuid: None,
        }
    }
}

fn dirs_home() -> PathBuf {
    directories::UserDirs::new()
        .map(|d| d.home_dir().to_path_buf())
        .unwrap_or_else(|| PathBuf::from("."))
}

pub fn config_file() -> Result<PathBuf> {
    let dirs = ProjectDirs::from("com", "Minty", "Minty Launcher")
        .context("Не удалось определить каталог конфигурации")?;
    fs::create_dir_all(dirs.config_dir())?;
    Ok(dirs.config_dir().join("settings.json"))
}

pub fn data_dir() -> Result<PathBuf> {
    let dirs = ProjectDirs::from("com", "Minty", "Minty Launcher")
        .context("Не удалось определить каталог данных")?;
    fs::create_dir_all(dirs.data_local_dir())?;
    Ok(dirs.data_local_dir().to_path_buf())
}

pub fn load() -> Result<AppConfig> {
    let path = config_file()?;
    if !path.exists() {
        let config = AppConfig::default();
        save(&config)?;
        return Ok(config);
    }
    let raw = fs::read_to_string(&path).with_context(|| format!("Не удалось прочитать {}", path.display()))?;
    let config = serde_json::from_str(&raw).context("Файл настроек повреждён или имеет несовместимый формат")?;
    Ok(config)
}

pub fn save(config: &AppConfig) -> Result<()> {
    let path = config_file()?;
    let raw = serde_json::to_string_pretty(config)?;
    let temp = path.with_extension("json.tmp");
    fs::write(&temp, raw)?;
    if path.exists() {
        fs::remove_file(&path)?;
    }
    fs::rename(temp, path)?;
    Ok(())
}
