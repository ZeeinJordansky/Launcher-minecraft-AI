use crate::{auth::{self, Account, AuthEvent}, config::{self, AppConfig}, minecraft::{self, LaunchEvent, VersionInfo}};
use crossbeam_channel::{unbounded, Receiver, Sender};
use eframe::egui::{self, Align, Color32, FontId, Layout, RichText, Rounding, Stroke};
use std::{thread, time::Duration};

const BG: Color32 = Color32::from_rgb(12, 19, 17);
const PANEL: Color32 = Color32::from_rgb(20, 31, 27);
const PANEL_LIGHT: Color32 = Color32::from_rgb(28, 43, 37);
const MINT: Color32 = Color32::from_rgb(112, 231, 177);
const MINT_DARK: Color32 = Color32::from_rgb(42, 143, 104);
const TEXT: Color32 = Color32::from_rgb(232, 242, 236);
const MUTED: Color32 = Color32::from_rgb(148, 169, 157);
const RED: Color32 = Color32::from_rgb(231, 107, 107);

#[derive(PartialEq, Eq, Clone, Copy)]
enum Page { Home, Installations, Settings }

pub struct MintyApp {
    config: AppConfig,
    page: Page,
    versions: Vec<VersionInfo>,
    latest_release: String,
    account: Option<Account>,
    auth_rx: Receiver<AuthEvent>,
    auth_tx: Sender<AuthEvent>,
    launch_rx: Option<Receiver<LaunchEvent>>,
    auth_busy: bool,
    launch_busy: bool,
    status: String,
    error: Option<String>,
    device_code: Option<(String, String, String)>,
    version_search: String,
    version_rx: Option<Receiver<Result<(Vec<VersionInfo>, String), String>>>,
    ctx: egui::Context,
}

impl MintyApp {
    pub fn new(cc: &eframe::CreationContext<'_>) -> Self {
        configure_style(&cc.egui_ctx);
        let config = config::load().unwrap_or_default();
        let (auth_tx, auth_rx) = unbounded();
        let mut app = Self {
            config,
            page: Page::Home,
            versions: Vec::new(),
            latest_release: String::new(),
            account: None,
            auth_rx,
            auth_tx,
            launch_rx: None,
            auth_busy: false,
            launch_busy: false,
            status: "Добро пожаловать в Minty Launcher".to_owned(),
            error: None,
            device_code: None,
            version_search: String::new(),
            version_rx: None,
            ctx: cc.egui_ctx.clone(),
        };
        app.load_versions();
        app.refresh_account();
        app
    }

    fn load_versions(&mut self) {
        self.status = "Подключаюсь к серверам Mojang…".to_owned();
        let (tx, rx) = unbounded::<Result<(Vec<VersionInfo>, String), String>>();
        self.version_rx = Some(rx);
        let ctx = self.ctx.clone();
        thread::spawn(move || {
            let result = minecraft::fetch_versions().map_err(|e| format!("{e:#}"));
            tx.send(result).ok();
            ctx.request_repaint();
        });
    }

    fn refresh_account(&mut self) {
        if self.config.microsoft_client_id.trim().is_empty() { return; }
        let client_id = self.config.microsoft_client_id.clone();
        let tx = self.auth_tx.clone();
        self.auth_busy = true;
        thread::spawn(move || match auth::refresh_saved_account(&client_id) {
            Ok(account) => { tx.send(AuthEvent::Connected(account)).ok(); }
            Err(error) => { tx.send(AuthEvent::Failed(format!("Автовход: {error:#}"))).ok(); }
        });
    }

    fn begin_login(&mut self) {
        if self.config.microsoft_client_id.trim().is_empty() {
            self.error = Some("Укажи Microsoft OAuth Client ID в настройках. Без него официальный вход недоступен.".to_owned());
            self.page = Page::Settings;
            return;
        }
        if self.auth_busy { return; }
        self.auth_busy = true;
        self.error = None;
        self.device_code = None;
        self.status = "Запрашиваю код авторизации Microsoft…".to_owned();
        let client_id = self.config.microsoft_client_id.clone();
        let tx = self.auth_tx.clone();
        thread::spawn(move || {
            if let Err(error) = auth::login_device(&client_id, tx.clone()) {
                tx.send(AuthEvent::Failed(format!("{error:#}"))).ok();
            }
        });
    }

    fn start_game(&mut self) {
        if self.launch_busy { return; }
        if let Err(error) = config::save(&self.config) {
            self.error = Some(format!("Не удалось сохранить настройки: {error:#}"));
            return;
        }
        let account = self.account.clone().unwrap_or_else(|| Account {
            name: self.config.offline_username.trim().to_owned(),
            uuid: String::new(),
            xuid: String::new(),
            access_token: String::new(),
        });
        if account.name.is_empty() {
            self.error = Some("Введи имя игрока для офлайн-режима или войди через Microsoft.".to_owned());
            return;
        }
        if !valid_username(&account.name) {
            self.error = Some("Ник должен содержать от 3 до 16 латинских букв, цифр или подчёркиваний.".to_owned());
            return;
        }
        self.error = None;
        self.launch_busy = true;
        self.status = "Готовлю Minecraft к запуску…".to_owned();
        let config = self.config.clone();
        let (tx, rx) = unbounded();
        self.launch_rx = Some(rx);
        thread::spawn(move || {
            let _ = minecraft::launch(config, account, tx);
        });
    }

    fn apply_events(&mut self) {
        for event in self.auth_rx.try_iter() {
            match event {
                AuthEvent::DeviceCode(info) => {
                    self.device_code = Some((info.user_code, info.verification_uri.clone(), info.message));
                    self.status = "Подтверди вход в открывшемся окне Microsoft".to_owned();
                    let _ = open::that(info.verification_uri);
                }
                AuthEvent::Connected(account) => {
                    self.config.last_account_name = Some(account.name.clone());
                    self.config.last_account_uuid = Some(account.uuid.clone());
                    self.config.last_account_xuid = Some(account.xuid.clone());
                    let _ = config::save(&self.config);
                    self.status = format!("Вход выполнен: {}", account.name);
                    self.account = Some(account);
                    self.auth_busy = false;
                    self.device_code = None;
                    self.error = None;
                }
                AuthEvent::Failed(message) => {
                    // A failed silent refresh should not block offline play.
                    if !message.starts_with("Автовход:") { self.error = Some(message.clone()); }
                    self.status = message;
                    self.auth_busy = false;
                    self.device_code = None;
                }
            }
        }
        if let Some(rx) = &self.launch_rx {
            for event in rx.try_iter() {
                match event {
                    LaunchEvent::Status(message) => self.status = message,
                    LaunchEvent::Finished(message) => { self.status = message; self.launch_busy = false; }
                    LaunchEvent::Failed(message) => { self.error = Some(message.clone()); self.status = "Не удалось запустить Minecraft".to_owned(); self.launch_busy = false; }
                }
            }
        }
        let version_result = self.version_rx.as_ref().and_then(|rx| rx.try_recv().ok());
        if let Some(result) = version_result {
            self.version_rx = None;
            match result {
                    Ok((versions, latest)) => {
                        self.versions = versions;
                        self.latest_release = latest.clone();
                        if self.config.selected_version == "latest-release" { self.config.selected_version = latest; }
                        if self.versions.iter().all(|v| v.id != self.config.selected_version) {
                            self.config.selected_version = self.latest_release.clone();
                        }
                        let _ = config::save(&self.config);
                        self.status = format!("Список версий загружен · {} релизов", self.versions.len());
                    }
                    Err(error) => {
                        self.error = Some(format!("Не удалось получить версии: {error}"));
                        self.status = "Нет подключения к серверам Mojang".to_owned();
                    }
                }
        }
    }

    fn sidebar(&mut self, ctx: &egui::Context) {
        egui::SidePanel::left("sidebar")
            .exact_width(224.0)
            .resizable(false)
            .frame(egui::Frame::none().fill(Color32::from_rgb(15, 25, 21)).inner_margin(egui::Margin::same(18.0)))
            .show(ctx, |ui| {
                ui.vertical(|ui| {
                    ui.add_space(8.0);
                    ui.horizontal(|ui| {
                        ui.label(RichText::new("✳").size(31.0).color(MINT));
                        ui.vertical(|ui| {
                            ui.label(RichText::new("MINTY").size(19.0).strong().color(TEXT));
                            ui.label(RichText::new("LAUNCHER").size(10.0).strong().color(MUTED));
                        });
                    });
                    ui.add_space(34.0);
                    self.nav_button(ui, "⌂", "Главная", Page::Home);
                    self.nav_button(ui, "▣", "Установки", Page::Installations);
                    self.nav_button(ui, "⚙", "Настройки", Page::Settings);
                    ui.with_layout(Layout::bottom_up(Align::Min), |ui| {
                        ui.add_space(8.0);
                        ui.label(RichText::new(format!("v{} · Windows x64", env!("CARGO_PKG_VERSION"))).size(10.0).color(MUTED));
                        ui.label(RichText::new("MINTY PROJECT").size(9.0).color(MUTED));
                    });
                });
            });
    }

    fn nav_button(&mut self, ui: &mut egui::Ui, icon: &str, label: &str, page: Page) {
        let selected = self.page == page;
        let fill = if selected { PANEL_LIGHT } else { Color32::TRANSPARENT };
        let response = ui.add_sized([188.0, 43.0], egui::Button::new(
            RichText::new(format!("{icon}    {label}")).size(14.0).color(if selected { TEXT } else { MUTED })
        ).fill(fill).stroke(Stroke::new(0.0, Color32::TRANSPARENT)).rounding(Rounding::same(9.0)));
        if response.clicked() { self.page = page; }
        if selected { ui.painter().rect_filled(egui::Rect::from_min_size(response.rect.left_top(), egui::vec2(3.0, response.rect.height())), Rounding::same(2.0), MINT); }
        ui.add_space(5.0);
    }

    fn home_page(&mut self, ui: &mut egui::Ui) {
        ui.vertical(|ui| {
            ui.add_space(8.0);
            ui.label(RichText::new("ТВОЯ ИГРА. ТВОИ ПРАВИЛА.").size(11.0).strong().color(MINT));
            ui.add_space(7.0);
            ui.label(RichText::new("Привет, игрок 👋").size(29.0).strong().color(TEXT));
            ui.label(RichText::new("Minty Launcher подготовит Minecraft и запустит игру за тебя.").size(13.0).color(MUTED));
            ui.add_space(24.0);

            egui::Frame::none().fill(PANEL).rounding(Rounding::same(16.0)).inner_margin(egui::Margin::same(22.0)).show(ui, |ui| {
                ui.set_min_width(ui.available_width());
                ui.horizontal(|ui| {
                    ui.vertical(|ui| {
                        ui.label(RichText::new("ТЕКУЩАЯ УСТАНОВКА").size(10.0).strong().color(MUTED));
                        ui.add_space(5.0);
                        ui.label(RichText::new(if self.config.selected_version == "latest-release" { "Последний релиз" } else { &self.config.selected_version }).size(22.0).strong().color(TEXT));
                        ui.label(RichText::new("Minecraft · Java Edition · Vanilla").size(12.0).color(MUTED));
                    });
                    ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                        ui.label(RichText::new("✦").size(56.0).color(MINT_DARK));
                    });
                });
                ui.add_space(16.0);
                ui.horizontal(|ui| {
                    ui.label(RichText::new("Версия игры").color(TEXT).size(12.0));
                    egui::ComboBox::from_id_source("version_picker")
                        .selected_text(if self.config.selected_version.is_empty() { "Загрузка…" } else { &self.config.selected_version })
                        .width(220.0)
                        .show_ui(ui, |ui| {
                            if !self.latest_release.is_empty() {
                                ui.selectable_value(&mut self.config.selected_version, self.latest_release.clone(), format!("{} (последняя)", self.latest_release));
                            }
                            for version in self.versions.iter().take(100) {
                                ui.selectable_value(&mut self.config.selected_version, version.id.clone(), version.id.clone());
                            }
                        });
                    if ui.button("↻").on_hover_text("Обновить список версий").clicked() { self.load_versions(); }
                });
            });

            ui.add_space(15.0);
            ui.columns(2, |columns| {
                egui::Frame::none().fill(PANEL).rounding(Rounding::same(14.0)).inner_margin(egui::Margin::same(18.0)).show(&mut columns[0], |ui| {
                    ui.label(RichText::new("АККАУНТ").size(10.0).strong().color(MUTED));
                    ui.add_space(8.0);
                    if let Some(account) = &self.account {
                        ui.label(RichText::new(&account.name).size(18.0).strong().color(TEXT));
                        ui.label(RichText::new("Microsoft · лицензия подтверждена").size(11.0).color(MINT));
                        ui.add_space(7.0);
                        if ui.small_button("Выйти").clicked() {
                            auth::sign_out();
                            self.account = None;
                            self.config.last_account_name = None;
                            self.config.last_account_uuid = None;
                            self.config.last_account_xuid = None;
                            let _ = config::save(&self.config);
                        }
                    } else {
                        ui.label(RichText::new("Офлайн-режим").size(18.0).strong().color(TEXT));
                        ui.label(RichText::new("Для серверов войди через Microsoft").size(11.0).color(MUTED));
                        ui.add_space(5.0);
                        ui.horizontal(|ui| {
                            ui.add(egui::TextEdit::singleline(&mut self.config.offline_username).desired_width(110.0).hint_text("Ник игрока"));
                            if ui.small_button("Войти ↗").clicked() { self.begin_login(); }
                        });
                    }
                });
                egui::Frame::none().fill(PANEL).rounding(Rounding::same(14.0)).inner_margin(egui::Margin::same(18.0)).show(&mut columns[1], |ui| {
                    ui.label(RichText::new("ПАМЯТЬ JAVA").size(10.0).strong().color(MUTED));
                    ui.add_space(8.0);
                    ui.label(RichText::new(format!("{} GB", self.config.max_memory_gb)).size(23.0).strong().color(TEXT));
                    ui.add(egui::Slider::new(&mut self.config.max_memory_gb, 2..=16).show_value(false));
                    ui.label(RichText::new("Выделение оперативной памяти").size(11.0).color(MUTED));
                });
            });

            ui.add_space(18.0);
            ui.horizontal(|ui| {
                let button = egui::Button::new(RichText::new(if self.launch_busy { "ПОДГОТОВКА…" } else { "▶   ЗАПУСТИТЬ MINECRAFT" }).size(15.0).strong().color(Color32::from_rgb(10, 30, 21)))
                    .fill(MINT).min_size(egui::vec2(260.0, 50.0)).rounding(Rounding::same(12.0));
                if ui.add_enabled(!self.launch_busy, button).clicked() { self.start_game(); }
                ui.add_space(10.0);
                if ui.button(RichText::new("Открыть .minecraft").color(TEXT)).clicked() {
                    let _ = open::that(&self.config.game_dir);
                }
            });
            ui.add_space(10.0);
            ui.label(RichText::new("Офлайн-режим предназначен для одиночной игры. Для авторизованных серверов используй Microsoft-аккаунт.").size(10.0).color(MUTED));
        });
    }

    fn installations_page(&mut self, ui: &mut egui::Ui) {
        ui.add_space(10.0);
        ui.label(RichText::new("Установки").size(27.0).strong().color(TEXT));
        ui.label(RichText::new("Выбирай официальные релизы Minecraft Java Edition.").size(13.0).color(MUTED));
        ui.add_space(20.0);
        egui::Frame::none().fill(PANEL).rounding(Rounding::same(14.0)).inner_margin(egui::Margin::same(18.0)).show(ui, |ui| {
            ui.horizontal(|ui| {
                ui.label(RichText::new("Найти версию").color(TEXT));
                ui.add(egui::TextEdit::singleline(&mut self.version_search).desired_width(230.0).hint_text("Например, 1.21.4"));
            });
            ui.add_space(12.0);
            egui::ScrollArea::vertical().max_height(360.0).show(ui, |ui| {
                for version in self.versions.iter().filter(|v| self.version_search.is_empty() || v.id.contains(&self.version_search)) {
                    ui.horizontal(|ui| {
                        ui.label(RichText::new(&version.id).strong().color(TEXT));
                        ui.label(RichText::new("Release").size(10.0).color(MINT));
                        if let Some(date) = &version.time {
                            ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                                ui.label(RichText::new(date.get(..10).unwrap_or(date)).size(10.0).color(MUTED));
                            });
                        }
                        if ui.small_button(if self.config.selected_version == version.id { "Выбрана" } else { "Выбрать" }).clicked() {
                            self.config.selected_version = version.id.clone();
                            let _ = config::save(&self.config);
                        }
                    });
                    ui.add_space(7.0);
                    ui.separator();
                }
            });
            if self.versions.is_empty() {
                ui.label(RichText::new("Список версий ещё не загружен. Проверь подключение и нажми обновить на главной.").color(MUTED));
            }
        });
        ui.add_space(14.0);
        ui.label(RichText::new("Поддержка Fabric/Forge и импорт сборок появятся в следующих версиях. Сейчас запускается чистый Vanilla Minecraft.").size(11.0).color(MUTED));
    }

    fn settings_page(&mut self, ui: &mut egui::Ui) {
        ui.add_space(10.0);
        ui.label(RichText::new("Настройки").size(27.0).strong().color(TEXT));
        ui.label(RichText::new("Пути, память и авторизация.").size(13.0).color(MUTED));
        ui.add_space(18.0);
        egui::Frame::none().fill(PANEL).rounding(Rounding::same(14.0)).inner_margin(egui::Margin::same(20.0)).show(ui, |ui| {
            ui.set_max_width(720.0);
            field_label(ui, "ПАПКА MINECRAFT");
            ui.horizontal(|ui| {
                ui.label(RichText::new(self.config.game_dir.to_string_lossy()).size(11.0).color(TEXT));
                if ui.button("Открыть").clicked() { let _ = open::that(&self.config.game_dir); }
            });
            ui.add_space(14.0);
            field_label(ui, "MICROSOFT OAUTH CLIENT ID");
            ui.add(egui::TextEdit::singleline(&mut self.config.microsoft_client_id).desired_width(560.0).hint_text("Application (client) ID из Microsoft Entra"));
            ui.label(RichText::new("Нужен для официальной авторизации Microsoft. Создай приложение типа Public client / Mobile & desktop, включи Device Code Flow и добавь разрешения XboxLive.signin и offline_access.").size(10.0).color(MUTED));
            ui.add_space(14.0);
            field_label(ui, "JAVA EXECUTABLE (НЕОБЯЗАТЕЛЬНО)");
            ui.add(egui::TextEdit::singleline(&mut self.config.java_path).desired_width(560.0).hint_text("Пусто — Minty автоматически установит подходящую Java"));
            ui.add_space(14.0);
            field_label(ui, "ОПЕРАТИВНАЯ ПАМЯТЬ");
            ui.horizontal(|ui| {
                ui.add(egui::Slider::new(&mut self.config.max_memory_gb, 2..=16).suffix(" GB"));
                ui.label(RichText::new("Максимум 16 GB").size(10.0).color(MUTED));
            });
            ui.add_space(19.0);
            if ui.add_sized([170.0, 40.0], egui::Button::new(RichText::new("СОХРАНИТЬ").strong().color(Color32::from_rgb(10,30,21))).fill(MINT).rounding(Rounding::same(9.0))).clicked() {
                match config::save(&self.config) {
                    Ok(()) => { self.status = "Настройки сохранены".to_owned(); self.error = None; }
                    Err(error) => self.error = Some(format!("Не удалось сохранить настройки: {error:#}")),
                }
            }
        });
    }

    fn footer(&mut self, ui: &mut egui::Ui) {
        ui.add_space(10.0);
        ui.separator();
        ui.horizontal(|ui| {
            ui.label(RichText::new("●").color(if self.error.is_some() { RED } else { MINT }).size(10.0));
            ui.label(RichText::new(&self.status).size(11.0).color(MUTED));
        });
        if let Some((code, url, message)) = &self.device_code {
            ui.add_space(7.0);
            egui::Frame::none().fill(PANEL_LIGHT).rounding(Rounding::same(8.0)).inner_margin(egui::Margin::same(10.0)).show(ui, |ui| {
                ui.label(RichText::new(message).size(11.0).color(TEXT));
                ui.horizontal(|ui| {
                    ui.label(RichText::new(code).size(20.0).strong().color(MINT));
                    if ui.small_button("Открыть страницу").clicked() { let _ = open::that(url); }
                    if ui.small_button("Копировать код").clicked() { ui.output_mut(|o| o.copied_text = code.clone()); }
                });
            });
        }
        if let Some(error) = &self.error {
            ui.add_space(6.0);
            ui.label(RichText::new(error).size(11.0).color(RED));
        }
    }
}

impl eframe::App for MintyApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        self.apply_events();
        self.sidebar(ctx);
        egui::CentralPanel::default().frame(egui::Frame::none().fill(BG).inner_margin(egui::Margin::same(22.0))).show(ctx, |ui| {
            egui::TopBottomPanel::bottom("status_footer").frame(egui::Frame::none().fill(BG)).show_inside(ui, |ui| self.footer(ui));
            match self.page {
                Page::Home => self.home_page(ui),
                Page::Installations => self.installations_page(ui),
                Page::Settings => self.settings_page(ui),
            }
        });
        if self.auth_busy || self.launch_busy || self.version_rx.is_some() { ctx.request_repaint_after(Duration::from_millis(150)); }
        if self.auth_busy && self.device_code.is_none() {
            egui::Area::new(egui::Id::new("auth_busy_overlay")).anchor(egui::Align2::CENTER_CENTER, [0.0, 100.0]).show(ctx, |ui| {
                ui.label(RichText::new("Ожидание ответа Microsoft…").color(MINT).strong());
            });
        }
    }
}

fn configure_style(ctx: &egui::Context) {
    let mut style = (*ctx.style()).clone();
    style.visuals = egui::Visuals::dark();
    style.visuals.panel_fill = BG;
    style.visuals.window_fill = PANEL;
    style.visuals.extreme_bg_color = Color32::from_rgb(9, 15, 13);
    style.visuals.faint_bg_color = PANEL;
    style.visuals.selection.bg_fill = MINT_DARK;
    style.visuals.widgets.inactive.bg_fill = PANEL_LIGHT;
    style.visuals.widgets.inactive.fg_stroke = Stroke::new(1.0, TEXT);
    style.visuals.widgets.hovered.bg_fill = Color32::from_rgb(42, 65, 55);
    style.visuals.widgets.active.bg_fill = MINT_DARK;
    style.visuals.override_text_color = Some(TEXT);
    style.spacing.item_spacing = egui::vec2(9.0, 8.0);
    style.text_styles.insert(egui::TextStyle::Body, FontId::proportional(13.0));
    ctx.set_style(style);
}

fn field_label(ui: &mut egui::Ui, label: &str) {
    ui.label(RichText::new(label).size(10.0).strong().color(MUTED));
    ui.add_space(5.0);
}

fn valid_username(name: &str) -> bool {
    (3..=16).contains(&name.len()) && name.chars().all(|c| c.is_ascii_alphanumeric() || c == '_')
}
