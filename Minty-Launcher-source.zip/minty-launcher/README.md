# Minty Launcher

**Minty Launcher** — нативный лаунчер Minecraft Java Edition для Windows x64. Интерфейс и подготовка игры написаны на Rust (`egui`); небольшой Java 8-compatible bootstrap передаёт аргументы целевой JVM и запускает Minecraft в самом конце.

## Что уже реализовано

- Тёмный интерфейс в мятно-зелёной цветовой теме: главная страница, список установок и настройки.
- Получение списка официальных релизов Minecraft из манифеста Mojang.
- Выбор версии Minecraft Java Edition.
- Загрузка официального client JAR, библиотек, native-библиотек и ресурсов.
- Проверка SHA-1 для файлов, для которых Mojang публикует контрольную сумму; повреждённые файлы загружаются заново.
- Подготовка `natives` и формирование classpath/аргументов запуска на основе version JSON.
- Поиск установленной Java и автоматическая установка Temurin JRE нужной версии, если подходящей Java нет.
- Вход через Microsoft Device Code Flow с дальнейшей проверкой Xbox Live, XSTS, Minecraft Services, профиля и лицензии Java Edition.
- Refresh token хранится в системном хранилище учётных данных через `keyring`, а не в открытом JSON-конфиге.
- Офлайн-профиль для одиночной игры. Офлайн-режим не выдаёт лицензию и не обеспечивает авторизацию на серверах.
- Автоматическая Windows-сборка и GitHub Release через GitHub Actions.

## Скачать

Готовый `.exe` публикуется в разделе **Releases** после запуска workflow `Build and publish release` или после отправки тега вида `v0.1.0`.

- [Последние релизы](https://github.com/ZeeinJordansky/Launcher-minecraft-AI/releases)
- [Исходный код](https://github.com/ZeeinJordansky/Launcher-minecraft-AI)

## Первый запуск

1. Скачай `MintyLauncher.exe` из Releases и запусти.
2. Выбери релиз Minecraft на главной странице.
3. Для сетевой игры настрой Microsoft OAuth Client ID в «Настройки» и войди в аккаунт. Инструкция: [docs/AUTHENTICATION.md](docs/AUTHENTICATION.md).
4. Для одиночной игры можно указать ник и использовать офлайн-режим.
5. Нажми «Запустить Minecraft». При первом запуске лаунчер скачает необходимые файлы и Java Runtime.

## Сборка из исходников

Требуются Rust stable для `x86_64-pc-windows-msvc`, Visual Studio Build Tools с C++ workload и JDK 21 (команда `javac` должна быть доступна в `PATH`). Подробности — [docs/BUILDING.md](docs/BUILDING.md).

```powershell
cargo build --release
```

Результат: `target/release/minty-launcher.exe`.

## Структура проекта

```text
src/
  app.rs        интерфейс и UI-события
  auth.rs       Microsoft/Xbox/Minecraft Services авторизация
  config.rs     настройки и пути
  minecraft.rs  манифесты, загрузки, проверка файлов и запуск
  runtime.rs    поиск/установка Java Runtime
  main.rs       точка входа
java/
  MintyBootstrap.java
.github/workflows/
  ci.yml
  release.yml
docs/
  ARCHITECTURE.md
  AUTHENTICATION.md
  BUILDING.md
  TROUBLESHOOTING.md
```

## Важные ограничения первой версии

- Сейчас поддерживаются официальные **Vanilla release**. Установка Fabric, Forge, NeoForge, импорт сборок и встроенное управление модами ещё не реализованы.
- Проверка целостности относится к официальным загрузкам Mojang. Это не античит: лаунчер не может гарантированно распознавать все сторонние модификации или чит-клиенты на компьютере игрока.
- Microsoft OAuth требует собственного публичного Client ID приложения. Client Secret в клиентское приложение добавлять нельзя.
- Сборка `.exe` пока не подписана цифровым сертификатом, поэтому Windows SmartScreen может показывать предупреждение о неизвестном издателе.

## Лицензия

MIT. См. [LICENSE](LICENSE).
