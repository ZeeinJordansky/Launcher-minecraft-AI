# Архитектура Minty Launcher

## Компоненты

### Rust — основной процесс

- `app.rs`: окно `egui`, страницы, настройки, фоновые задачи и сообщения о состоянии.
- `config.rs`: конфигурация в каталоге пользователя и определение `.minecraft`.
- `auth.rs`: публичный Microsoft Device Code Flow, обмен токенов Xbox Live/XSTS, Minecraft Services, проверка профиля и лицензии. Refresh token сохраняется через системное credential store.
- `minecraft.rs`: манифест версий Mojang, version JSON, client JAR, библиотеки, native-библиотеки, asset index и assets. При наличии опубликованного SHA-1 выполняется проверка перед использованием файла.
- `runtime.rs`: обнаружение Java и загрузка Temurin JRE для нужной major-версии, если совместимой Java нет.

### Java — последний этап запуска

`build.rs` компилирует `java/MintyBootstrap.java` в Java 8 bytecode. Класс встраивается в Rust-бинарник. Перед запуском Rust записывает его в каталог данных и вызывает bootstrap подходящей Java Runtime. Bootstrap создаёт `ProcessBuilder`, запускает целевую JVM с подготовленными аргументами Minecraft, передаёт стандартные потоки и возвращает код завершения.

Java bootstrap не содержит токенов, не выполняет сетевую авторизацию и не принимает решений о доверии к файлам.

## Каталоги

- `.minecraft/versions/<id>/` — version JSON и client JAR.
- `.minecraft/libraries/` — официальные библиотеки.
- `.minecraft/assets/` — индекс и игровые ресурсы.
- `.minecraft/natives/<id>/` — распакованные native-библиотеки.
- Пользовательский конфиг: `%APPDATA%/Minty/Minty Launcher/settings.json`.
- Java Runtime и bootstrap: `%LOCALAPPDATA%/Minty/Minty Launcher/`.
- Refresh token: системное хранилище учётных данных Windows (через `keyring`).

## Границы безопасности

1. Все URL игровых артефактов берутся из официальных метаданных Mojang; TLS проверяется HTTP-клиентом.
2. SHA-1 используется только для проверки совпадения с хешем, опубликованным Mojang. Это контроль целостности загрузки, не самостоятельная криптографическая подпись и не античит.
3. ZIP-архивы извлекаются с проверкой безопасного относительного пути.
4. Microsoft refresh token не записывается в `settings.json`.
5. Клиентский лаунчер не может обеспечить надёжную защиту от читов на машине пользователя. Серверная проверка и правила конкретного сервера остаются ответственностью сервера.
