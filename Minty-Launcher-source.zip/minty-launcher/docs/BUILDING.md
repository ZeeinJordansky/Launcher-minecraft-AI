# Сборка Minty Launcher на Windows

## Инструменты

- Windows 10/11 x64.
- Rust stable и Cargo: https://www.rust-lang.org/tools/install
- Visual Studio 2022 Build Tools с workload **Desktop development with C++** (MSVC linker и Windows SDK).
- JDK 21 x64. После установки команда `javac -version` должна выполняться из нового терминала.

Java bootstrap компилируется при сборке Rust-проекта командой `javac --release 8`. Это отдельный этап build script, поэтому одного JRE недостаточно.

## Сборка

В корне репозитория:

```powershell
cargo build --release
```

Готовый файл:

```text
target\release\minty-launcher.exe
```

Для локальной отладки:

```powershell
cargo run
```

## Автоматическая сборка GitHub Actions

Workflow `.github/workflows/ci.yml` собирает приложение на `windows-latest` при push и pull request.

Workflow `.github/workflows/release.yml`:

- запускается при push тега `v*`;
- также доступен вручную в Actions → Build and publish release → Run workflow;
- собирает Release-конфигурацию под Windows x64;
- прикладывает `MintyLauncher.exe` к GitHub Release.

Для первой публикации можно открыть вкладку Actions, выбрать workflow **Build and publish release**, нажать **Run workflow** и указать тег `v0.1.0`. Workflow создаст Release с бинарником.
